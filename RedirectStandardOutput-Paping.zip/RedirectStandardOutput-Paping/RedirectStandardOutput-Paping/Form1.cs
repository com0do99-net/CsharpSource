﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace RedirectStandardOutput_Paping
{
    public partial class Form1 : Form
    {
        delegate void SetTextCallback(string text);

        public Form1()
        {
            InitializeComponent();
        }


        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.textBox1.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.textBox2.AppendText(text + Environment.NewLine);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process process;
            process = new Process();
            process.StartInfo.FileName = Application.StartupPath + "\\paping.exe";
            process.StartInfo.Arguments = textBox1.Text;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.OutputDataReceived += new DataReceivedEventHandler(OutputHandler);
            process.Start();
            process.BeginOutputReadLine();
        }

        public void OutputHandler(object sendingProcess, DataReceivedEventArgs outLine)
        {
            SetText(outLine.Data);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process[] pcs_check = Process.GetProcessesByName("paping");
            if (pcs_check.Length > 0)
                foreach (var p in pcs_check)
                    p.Kill();
        }
    }
}
